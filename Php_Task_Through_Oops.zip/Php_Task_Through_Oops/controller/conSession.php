<?php 
session_start();
session_unset();
header("Location:http://localhost/html/Php_Task_Through_Oops/view/viewLogin.php");
?>