$(document).ready(function () {
    // $(".hint-css").hide();



// $(".tgl").hover(function(){
//         $(".hint-css").show();
//     },function(){ 
//         $(".hint-css").hide();
//     });
    
});