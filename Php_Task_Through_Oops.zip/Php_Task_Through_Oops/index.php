<?php


require_once 'controller/loginController.php';
$loginController=new loginController();

$loginController->index();

?>
